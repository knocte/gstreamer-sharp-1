gstreamer-sharp
===============

Bindings for gstreamer-1.0 generated from introspection data

Compilation
==============

Open a terminal, navigate to the folder containting this repository and run:
``` Bash
./autogen.sh && make
```
